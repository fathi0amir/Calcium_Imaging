figure;
[Coor,json_file] = plot_contours(A_or,Cn,options,1); % contour plot of spatial footprints

Ambig_Cell = [10, 22, 21, 17, 2, 18, 13, 15, 4];

A_or_Fll = full(A_or);
A_or_Cln = A_or_Fll;
A_or_Cln(:, Ambig_Cell) = [];

figure; plot_contours(A_or_Cln,Cn,options,1);

C_df_Fll = full(C_df);
C_df_Cln = C_df_Fll;
C_df_Cln(Ambig_Cell, :) = [];
figure; imagesc(C_df_Cln)

figure; plot_components_GUI(Yr_,A_or,C_or,b2,f2,Cn,options); % modified!!! 


[C_df_Crl, C_df_P] = corrcoef(C_df_Cln');
figure; plotmatrix(C_df_Cln')

 

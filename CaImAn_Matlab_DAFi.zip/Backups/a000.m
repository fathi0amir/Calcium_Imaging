function a000
% Get screen resolution
scrn_res_pxl = get(0, "ScreenSize"); % Screen Resolution Pixe
% Create a window for placing the items for user input
wh = scrn_res_pxl(4)/2; % Window Height
ww = 400; % Window Width
top_off = 10; % Top Offset between the items
voff = 22; % Vertical offset
dh = 30; % UIControl default height

f = figure("Position",[750 250 ww wh ]); % Tope menu bar is 84

clr_ws = uicontrol(f, "Style","checkbox", "String" , "Clear Workspace?",...
    "Position", [25 wh-voff-top_off ww dh], "Value", 1);

save_mat = uicontrol(f, "Style","checkbox", "String" , "Save a mat file with" + ...
    "all the variable in the workspace?",...
    "Position", [25 wh-voff*2-top_off ww dh], "Value", 1);

manual_refine = uicontrol(f, "Style","checkbox", "String" , "Manually refine the ROI selection?",...
    "Position", [25 wh-voff*3-top_off ww 30], "Value", 0);

crop_image = uicontrol(f, "Style","checkbox", "String" , "Crop the image?",...
    "Position", [25 wh-voff*4-top_off ww dh], "Value", 0);

crop_coordinate_text = uicontrol(f, "Style","text", "String", "X1  |  X2  |  Y1  |  Y2  ", ...
    "Position", [25 wh-voff*5.2-top_off 100 dh ]);
crop_coordinate = uicontrol(f, "Style","edit", "String", "100, 450, 300, 450",...
    "Position", [25 wh-voff*6-top_off 100 dh]);

do_mtn_crcn = uicontrol(f, "Style","checkbox", "String" , "Do Motion Correction?",...
    "Position", [25 wh-voff*7.4-top_off ww dh], "Value", 1);

do_scn_phs_crcn = uicontrol(f, "Style","checkbox", "String" , "Do line phase correction?",...
    "Position", [25 wh-voff*8.4-top_off ww dh], "Value", 1);

mk_mv = uicontrol(f, "Style","checkbox", "String" , "Save the processed image stack as a movie?",...
    "Position", [25 wh-voff*9.4-top_off ww dh], "Value", 0);

n_avrg_text = uicontrol(f, "Style","text", "String", "Number of average", ...
    "Position", [25 wh-voff*10.9-top_off 100 dh]);
n_avrg = uicontrol(f, "Style","edit", "String", "6",...
    "Position", [125 wh-voff*10.6-top_off 50 dh]);

brk_stck = uicontrol(f, "Style","checkbox", "String" , "Break the stack to smaller stacks?",...
    "Position", [25 wh-voff*12-top_off ww dh], "Value", 0);
n_sgmt_text = uicontrol(f, "Style","text", "String", "Number of sub-stacks (segments)", ...
    "Position", [25 wh-voff*13.5-top_off 200 dh]);
n_sgmt = uicontrol(f, "Style","edit", "String", "3",...
    "Position", [225 wh-voff*13.2-top_off 50 dh]);
trgt_sgmt_text = uicontrol(f, "Style","text", "String", "Which sub-stack to process?", ...
    "Position", [25 wh-voff*15-top_off 180 dh]);
trgt_sgmt = uicontrol(f, "Style","edit", "String", "1",...
    "Position", [225 wh-voff*14.6-top_off 50 dh]);

gssn_xyz_text = uicontrol(f, "Style","text", "String", "X | Y | Z 3D guassian smoothing parameters", ...
    "Position", [25 wh-voff*16-top_off 220 dh]);
gssn_xyz = uicontrol(f, "Style","edit", "String", "1, 0.9, 3",...
    "Position", [30 wh-voff*17-top_off 50 dh]);

hstm_stch_tshd_text = uicontrol(f, "Style","text", "String", "Histogram streching threshhold", ...
    "Position", [25 wh-voff*18.7-top_off 160 dh]);
hstm_stch_tshd = uicontrol(f, "Style","edit", "String", "2000",...
    "Position", [185 wh-voff*18.3-top_off 50 dh]);

gssn_hstm_stch_tshd_text = uicontrol(f, "Style", "text", "String", "Histogram streching threshhold (smoothed image)", ...
    "Position", [25 wh-voff*20.1-top_off 250 dh]);
gssn_hstm_stch_tshd = uicontrol(f, "Style", "edit", "String", "5000",...
    "Position", [275 wh-voff*19.8-top_off 50 dh]);

% -------------------------------
exitReturn = uicontrol(f, "Style","pushbutton", "String","Save to Workspace", ...
    "Position", [20 10 150 30]);
exitReturn.Callback = @exitReturn_Callback;
uiwait(f); 
    function exitReturn_Callback(hObject, eventdata)
        % hObject    handle to pushbutton1 (see GCBO)
        % eventdata  reserved - to be defined in a future version of MATLAB
        % handles    structure with handles and user data (see GUIDATA)
        disp('Goodbye');
        assignin("base", "clr_ws", clr_ws.Value);
        assignin("base", "save_mat", save_mat.Value);
        assignin("base", "manual_refine", manual_refine.Value);
        assignin("base", "crop_image", crop_image.Value);
        assignin("base", "crop_coordinate", str2num(crop_coordinate.String));
        assignin("base", "do_mtn_crcn", do_mtn_crcn.Value);
        assignin("base", "do_scn_phs_crcn", do_scn_phs_crcn.Value);
        assignin("base", "mk_mv", mk_mv.Value);
        assignin("base", "n_avrg", str2num(n_avrg.String));
        assignin("base", "brk_stck", brk_stck.Value);
        assignin("base", "n_sgmt", str2num(n_sgmt.String));
        assignin("base", "trgt_sgmt", str2num(trgt_sgmt.String));
        assignin("base", "gssn_xyz", str2num(gssn_xyz.String));
        assignin("base", "hstm_stch_tshd", str2num(hstm_stch_tshd.String));
        assignin("base", "gssn_hstm_stch_tshd", str2num(gssn_hstm_stch_tshd.String));
        close(f);
    end

end
